# Lab 6

This is code template for SENG 299 Summer 2016 Lab 6. 

## Usage

To run the server: 

1. Checkout/download the code: `git clone https://github.com/sdiemert/seng299lab.git`
2. Move to lab 6 directory: `cd seng299lab/lab6`
3. Start the server: `node server.js`

Navigate to `http://localhost:3000` to view the web appliation.
