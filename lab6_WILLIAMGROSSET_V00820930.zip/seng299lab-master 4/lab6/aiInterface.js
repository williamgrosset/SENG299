var http = require("http");

function getRandomMove(size, board, lastMove, cb){
    
    var options = {
        host: "roberts.seng.uvic.ca",
        path: "/ai/random",
        port: 30000,
        method: "POST",
        headers: {
            'Content-Type': "application/json"
        }
    };
    
    var callback = function(response) {
        var str = "";
        response.on('data', function(chunk) {
            str += chunk.toString();
            //console.log(chunk.toString());
        });
        
        response.on('end', function() {
            console.log('No more response.');
            //console.log(str);
            cb(JSON.parse(str));
        });
    }
    
    var req = http.request(options, callback);
    
    req.on('error', function(e) {
        console.log(`Problem with request: ${e.message}`);
    })
    
    var postData = JSON.stringify({
        'size': size,
        'board': board,
        'last': lastMove,
    });

    req.write(postData);
    req.end();
}

module.exports = {
    getRandomMove : getRandomMove
}