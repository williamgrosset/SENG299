window.onload = function() {   
   document.getElementById('delete-project-button').onclick = function() {
       var checks = document.getElementsByClassName('delete-project-check');
       for (var i = 0; i < checks.length; i++) {
           if (checks[i].checked) {
               checks[i].parentNode.parentNode.remove();
               i--;
           }
       }
   }
   
   var btn = document.getElementById('end-activity-button');
   btn.style.display = 'none';
    
   document.getElementById('new-activity-button').onclick = function() {
       btn.style.display = 'inline';
       var table = document.getElementById('projects'); // append row to this table
       var row = table.insertRow(table.length); // create row
       
       var cell1 = row.insertCell(0);
       var cell2 = row.insertCell(1);
       var cell3 = row.insertCell(2);
       var cell4 = row.insertCell(3);
       var cell5 = row.insertCell(4);
       var cell6 = row.insertCell(5);
       
       // Create checkbox cell
       var checkbox = document.createElement('input');
       checkbox.setAttribute('type', 'checkbox');
       checkbox.className = 'delete-project-check';
       cell1.appendChild(checkbox);

       
       // Create activity task cell
       var activity = document.getElementById('new-activity').value;
       cell2.innerHTML = activity;
       cell2.className = 'cell';

       
       // Create project name cell
       var project = document.getElementById('new-project').value;
       cell3.innerHTML = project;
       cell3.className = 'cell';
       
       // Create start time cell
       var time1 = new Date();
       var hoursStart = time1.getHours();
       var minutesStart = time1.getMinutes();
       var secondsStart = time1.getSeconds();
       cell4.innerHTML = hoursStart + ':' + minutesStart + ':' + secondsStart;
       cell4.className = 'cell';

       // Replace new text with original text
       document.getElementById('end-activity-button').onclick = function(){
           
           btn.style.display = 'none'; // hide end-activity button
           // Create completion time cell
           var time2 = new Date();
           var hoursCompletion = time2.getHours();
           var minutesCompletion = time2.getMinutes();
           var secondsCompletion = time2.getSeconds();
           cell5.innerHTML = hoursCompletion + ':' + minutesCompletion + ':' + secondsCompletion;
           cell5.className = 'cell';
           // Create time spent cell
           var secondsSpent = (hoursCompletion - hoursStart) + ':' + (minutesCompletion - minutesStart) + ':' + (secondsCompletion - secondsStart);
           cell6.innerHTML = secondsSpent;
           cell6.className = 'cell';
       }
   }
   
   
   // Delete projects
   document.getElementById('delete-all-projects-button').onclick = function(){
       var table = document.getElementById('projects');
       
       // Delete all except first row
       for (var i = table.rows.length-1; i> 0; i--) {
           table.deleteRow(i);
       }
   }
}