var express = require('express');
var bodyParser = require('body-parser');

var app = express();

// use the parse to get JSON objects out of the request.
app.use(bodyParser.json());

// server static files from the public directory
app.use(express.static('public'));


var myData = [];


/*
var myData = [
    {animal : 'lion', name : 'alex'},
    {animal : 'hippo', name : 'gloria'},
    {animal : 'giraffe', name : 'melmen'},
    {animal : 'zebra', name : 'marty'},
];
*/


app.get('/data', function(req, res) {
    console.log('(/data) Reload: Get Request to: /');
    res.json(myData);
})

app.post('/data', function(req,res) {
    console.log('(/data) POST Request to: /');
    myData.push(req.body);
    console.log(myData);
})


app.post('/endtask', function(req,res) {
    var lastRow = myData[myData.length -1] ;
    lastRow.endTime = req.body.endTime;
    lastRow.timeSpent = req.body.timeSpent;
    console.log(myData);
})

app.post('/delete', function(req,res) {
    console.log('(/delete) POST request to: /');
    //console.log(myData);
    var deleted = req.body; // array of indexes to be deleted
    for (var i = 0; i < deleted.length; i++) {
        myData.splice(deleted[i]-1,1);
    }
})

app.listen(3000, function() {
    console.log('Listening on port 3000');
})