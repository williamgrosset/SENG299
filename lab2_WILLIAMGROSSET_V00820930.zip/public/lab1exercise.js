var xhttp = new XMLHttpRequest();
xhttp.open('GET', '/data', true)
xhttp.send();

// Global Variables
var hoursStart = '';
var minutesStart = '';
var secondsStart = '';
var row;

xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
        
        var x = JSON.parse(xhttp.responseText);
        var s = x.length;
 
        // CASE 1
        if ( (x.length != 0 && x[x.length-1].endTime == undefined) ) {
            
            s = s - 1; // excluding last row in table
            for (var i = 0; i < s; i++) {
            
                var activity = x[i].activity;
                var project = x[i].project;
                var startTime = x[i].startTime.hoursStart + ":" + x[i].startTime.minutesStart + ":" + x[i].startTime.secondsStart;
                var endTime = x[i].endTime.hoursCompletion + ":" + x[i].endTime.minutesCompletion + ":" + x[i].endTime.secondsCompletion;
                var timeSpent = x[i].timeSpent;
                
                var table = document.getElementById('projects'); // append row to this table
                row = table.insertRow(table.length); // create row and add to table

                var cell1 = row.insertCell(0);
                var cell2 = row.insertCell(1);
                var cell3 = row.insertCell(2);
                var cell4 = row.insertCell(3);
                var cell5 = row.insertCell(4);
                var cell6 = row.insertCell(5);

                // Create checkbox cell
                var checkbox = document.createElement('input');
                checkbox.setAttribute('type', 'checkbox');
                checkbox.className = 'delete-project-check';
                cell1.appendChild(checkbox);

                // Create activity task cell
                cell2.innerHTML = activity;
                cell2.className = 'cell';

                // Create project name cell
                cell3.innerHTML = project;
                cell3.className = 'cell';

                // Create start time cell
                cell4.innerHTML = startTime;
                cell4.className = 'cell';

                // Create end time cell
                cell5.innerHTML = endTime;
                cell5.className = 'cell';

                // Create time spent cell
                cell6.innerHTML = timeSpent;
                cell6.className = 'cell'; 
        }
            lastrow = x[x.length-1];
            
            var table = document.getElementById('projects'); // append row to this table
            row = document.createElement('tr');

            var cell1 = row.insertCell(0);
            var cell2 = row.insertCell(1);
            var cell3 = row.insertCell(2);
            var cell4 = row.insertCell(3);
            var cell5 = row.insertCell(4);
            var cell6 = row.insertCell(5);

            // Create new data for row
            // Create checkbox cell
            var checkbox = document.createElement('input');
            checkbox.setAttribute('type', 'checkbox');
            checkbox.className = 'delete-project-check';
            cell1.appendChild(checkbox);


            // Create activity task cell
            var activity = document.getElementById('new-activity').value;
            cell2.innerHTML = lastrow.activity;
            cell2.className = 'cell';


            // Create project name cell
            var project = document.getElementById('new-project').value;
            cell3.innerHTML = lastrow.project;
            cell3.className = 'cell';

            // Create start time cell
            var time1 = new Date();
            hoursStart = lastrow.startTime.hoursStart;
            minutesStart = lastrow.startTime.minutesStart;
            secondsStart =  lastrow.startTime.secondsStart;
            var startTime = hoursStart + ':' + minutesStart + ':' + secondsStart;
            cell4.innerHTML = startTime;
            cell4.className = 'cell'; 
        }
    
        // CASE 2
        else {
            for (var i = 0; i < s; i++) {
            
                var activity = x[i].activity;
                var project = x[i].project;
                var startTime = x[i].startTime.hoursStart + ":" 
                            + x[i].startTime.minutesStart + ":" 
                            + x[i].startTime.secondsStart;
                var endTime = x[i].endTime.hoursCompletion + ":" 
                            + x[i].endTime.minutesCompletion + ":" 
                            + x[i].endTime.secondsCompletion;
                var timeSpent = x[i].timeSpent;
                
                var table = document.getElementById('projects'); // append row to this table
                row = table.insertRow(table.length); // create row and add to table

                var cell1 = row.insertCell(0);
                var cell2 = row.insertCell(1);
                var cell3 = row.insertCell(2);
                var cell4 = row.insertCell(3);
                var cell5 = row.insertCell(4);
                var cell6 = row.insertCell(5);

                // Create checkbox cell
                var checkbox = document.createElement('input');
                checkbox.setAttribute('type', 'checkbox');
                checkbox.className = 'delete-project-check';
                cell1.appendChild(checkbox);

                // Create activity task cell
                cell2.innerHTML = activity;
                cell2.className = 'cell';

                // Create project name cell
                cell3.innerHTML = project;
                cell3.className = 'cell';

                // Create start time cell
                cell4.innerHTML = startTime;
                cell4.className = 'cell';

                // Create end time cell
                cell5.innerHTML = endTime;
                cell5.className = 'cell';

                // Create time spent cell
                cell6.innerHTML = timeSpent;
                cell6.className = 'cell'; 
            }
        }
    }
}



window.onload = function() {   
    
   document.getElementById('delete-project-button').onclick = function() {
       var checks = document.getElementsByClassName('delete-project-check');
       var deleted = [];
       for (var i = 0; i < checks.length; i++) {
           var k = 0;
           if (checks[i].checked) {
               deleted.push(k); // push index into array
               checks[i].parentNode.parentNode.remove();
               k=k+1;
               i--;
           }
       }
       var deletePostXHttp = new XMLHttpRequest(); // setup post request
       deletePostXHttp.open('POST', '/delete', true);
       deletePostXHttp.setRequestHeader('Content-type', 'application/json');
       deletePostXHttp.send(JSON.stringify(deleted));
   }
   
   //var btn = document.getElementById('end-activity-button');
   //btn.style.display = 'none'; disabled for refresh
    
   document.getElementById('new-activity-button').onclick = function() {
       //btn.style.display = 'inline';
       var table = document.getElementById('projects'); // append row to this table
       //var row = table.insertRow(table.length); // create row
       row = document.createElement('tr');
       
       var cell1 = row.insertCell(0);
       var cell2 = row.insertCell(1);
       var cell3 = row.insertCell(2);
       var cell4 = row.insertCell(3);
       var cell5 = row.insertCell(4);
       var cell6 = row.insertCell(5);
       
       // Create checkbox cell
       var checkbox = document.createElement('input');
       checkbox.setAttribute('type', 'checkbox');
       checkbox.className = 'delete-project-check';
       cell1.appendChild(checkbox);

       
       // Create activity task cell
       var activity = document.getElementById('new-activity').value;
       cell2.innerHTML = activity;
       cell2.className = 'cell';

       
       // Create project name cell
       var project = document.getElementById('new-project').value;
       cell3.innerHTML = project;
       cell3.className = 'cell';
       
       // Create start time cell
       var time1 = new Date();
       hoursStart = time1.getHours();
       minutesStart = time1.getMinutes();
       secondsStart = time1.getSeconds();
       var startTime = hoursStart + ':' + minutesStart + ':' + secondsStart;
       cell4.innerHTML = startTime;
       cell4.className = 'cell';
       
       
       
       //table.appendChild(row);
       // gather all table data and place in object
       var startData = {
           'activity':activity, 
           'project':project, 
           'startTime':{
               'hoursStart':hoursStart,
               'minutesStart':minutesStart,
               'secondsStart':secondsStart
           }
       };
           
       // POST request to server
       console.log('sending POST to /data');
       var postXHttp = new XMLHttpRequest();
       postXHttp.open('POST', '/data', true);
       postXHttp.setRequestHeader('Content-type', 'application/json');
       postXHttp.send(JSON.stringify(startData));  
   }
   
   // Replace new text with original text
   document.getElementById('end-activity-button').onclick = function(){
        var table = document.getElementById('projects'); // append row to this table
        var cell5 = row.cells[4];
        var cell6 = row.cells[5];
           
        //btn.style.display = 'none'; // hide end-activity button (commented out for refresh)
        //Create completion time cell
        var time2 = new Date();
        var hoursCompletion = time2.getHours();
        var minutesCompletion = time2.getMinutes();
        var secondsCompletion = time2.getSeconds();
        var endTime = hoursCompletion + ':' + minutesCompletion + ':' + secondsCompletion;
        cell5.innerHTML = endTime;
        cell5.className = 'cell';
        console.log(cell5);
        // Create time spent cell
        var secondsSpent = (hoursCompletion*3600-hoursStart*3600) + (minutesCompletion*60-minutesStart*60) + (secondsCompletion - secondsStart);
        cell6.innerHTML = secondsSpent;
        cell6.className = 'cell';
           
           
        table.appendChild(row);
        // gather all new row data and place in object
        var finalData = {
            'endTime':{
                'hoursCompletion':hoursCompletion,
                'minutesCompletion':minutesCompletion,
                'secondsCompletion':secondsCompletion
            }, 
            'timeSpent': secondsSpent
        };
        //var finalData = {'activity':activity, 'project':project, 'start':startTime,'end':endTime, 'timespent':secondsSpent};
           
        // POST request to server
        console.log('sending POST to /data');
        var postXHttp = new XMLHttpRequest();
        postXHttp.open('POST', '/endtask', true);
        postXHttp.setRequestHeader('Content-type', 'application/json');
        postXHttp.send(JSON.stringify(finalData));
    }
   
   // Delete projects
   document.getElementById('delete-all-projects-button').onclick = function(){
       var table = document.getElementById('projects');
          
       // Delete all except first heading row
       var deleted = [];
       
       for (var i = table.rows.length-1; i> 0; i--) {
           table.deleteRow(i);
           deleted.push(i); // push row index into array
       }
       
       var deletePostXHttp = new XMLHttpRequest(); // setup post request
       deletePostXHttp.open('POST', '/delete', true);
       deletePostXHttp.setRequestHeader('Content-type', 'application/json');
       deletePostXHttp.send(JSON.stringify(deleted));
       
   }
}